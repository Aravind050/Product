package com.example.educationalLoan.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.educationalLoan.Model.UserModel;
import com.example.educationalLoan.Service.UserService;

@RestController
public class AdminController {
	@Autowired
	UserService Us;
	@GetMapping("/getData")
	public List<UserModel> getData(){
		return Us.getUserDetails();
	}
	@PostMapping("/post")
	public UserModel postMethod(@RequestBody UserModel e){
		return Us.userInserted(e);
	}
	@GetMapping("/get/{id}")
	public Optional <UserModel> getId(@PathVariable int id){
		return Us.userValue(id);
	}
	@PutMapping("/puts")
	public UserModel update(@RequestBody UserModel x){
		return Us.put(x);
	}
	@DeleteMapping("/delete/{id}")
	public String Delete(@PathVariable int id){
		return Us.deleteById(id);
	}
}
