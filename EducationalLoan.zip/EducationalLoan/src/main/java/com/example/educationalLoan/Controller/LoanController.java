package com.example.educationalLoan.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.educationalLoan.Model.LoanApplicationModel;
import com.example.educationalLoan.Service.LoanService;

@RestController
public class LoanController {
	@Autowired
	LoanService Ls;
	@PostMapping("/pst")
	public LoanApplicationModel postMethod(@RequestBody LoanApplicationModel e)
	{
		return Ls.insertval(e);
	}
	@GetMapping("/gets/{id}")
	public Optional <LoanApplicationModel> getId(@PathVariable int id)
	{
		return Ls.getValue(id);
	}
	@PutMapping("/put")
	public LoanApplicationModel update(@RequestBody LoanApplicationModel x)
	{
		return Ls.putMethod(x);
	}
	@DeleteMapping("/del/{id}")
	public String delete(@PathVariable int id)
	{
		return Ls.deleteById(id);
	}
	@GetMapping("/gets")
	public List<LoanApplicationModel> get()
	{
		return Ls.Print();
	}
}
