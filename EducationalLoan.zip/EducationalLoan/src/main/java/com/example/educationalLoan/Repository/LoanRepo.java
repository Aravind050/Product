package com.example.educationalLoan.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.educationalLoan.Model.LoanApplicationModel;

@Repository
public interface LoanRepo extends JpaRepository<LoanApplicationModel,Integer>{

}
