package com.example.educationalLoan.Service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.educationalLoan.Model.LoanApplicationModel;
import com.example.educationalLoan.Repository.LoanRepo;

@Service
public class LoanService {
	@Autowired
	LoanRepo Lr;
	public LoanApplicationModel insertval(LoanApplicationModel e) {
		return Lr.save(e);
	}
	public Optional<LoanApplicationModel> getValue(int id) {
		return Lr.findById(id);
	}
	public LoanApplicationModel putMethod(LoanApplicationModel x) {
		return Lr.save(x);
	}
	public String deleteById(int id) {
		Lr.deleteById(id);
		return id+" Deleted!!";
	}
	public List<LoanApplicationModel> Print() {
		return Lr.findAll();
	}
	
}
