package com.example.educationalLoan.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.educationalLoan.Model.UserModel;
import com.example.educationalLoan.Repository.UserRepo;

@Service
public class UserService {
	@Autowired
	UserRepo Ur;
	public UserModel userInserted(UserModel e) {
		return Ur.save(e);
	}
	public Optional<UserModel> userValue(int id) {
		return Ur.findById(id);
	}
	public List<UserModel> getUserDetails() {
		return Ur.findAll();
	}
	public UserModel put(UserModel x) {
		return Ur.save(x);
	}
	public String deleteById(int id) {
		Ur.deleteById(id);
		return id+" Deleted !!";
	}

}
