package com.golf.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.golf.model.Golf;
import com.golf.model.Matches;
import com.golf.service.ServiceClass;

@RestController
public class ControllerClass {
	@Autowired
	ServiceClass Sc;
//	@GetMapping("get")
//	public List<Matches> getData()
//	{
//		return Sc.getDataMatches();
//	}
//	@PutMapping("put")
//	public Matches saveData(@RequestBody Matches m)
//	{
//		return Sc.saveDataMatch(m);
//	}
	@GetMapping("/get")
	private List<Matches>getAllDetails()
	{
		return Sc.give();
	}
	@PostMapping("/post")
	private Matches post(@RequestBody Matches m)
	{
		return Sc.create(m);
	}
	@GetMapping("/getby/{field}")
	public List<Golf> getByField(@PathVariable ("field")String field)
	{
		return Sc.getbyfield(field);
	}
	@GetMapping("/getDataByPrefix")
	public List<Golf> getDataPrefix(@RequestParam String field)
	{
		return Sc.getPrefix(field);
	}
	@GetMapping("/getDataBySuffix")
	public List<Golf> getDataSuffix(@RequestParam String field)
	{
		return Sc.getSuffix(field);
	}
	@GetMapping("/query")
	public List<Golf>getDataByQuery(@RequestParam int a,@RequestParam String b)
	{
			return Sc.getByQuery(a,b);
	}
//	@DeleteMapping("/deleteDataQuery/{name})
//	public String deleteDataQuery(@RequestParam String name)
//	{
//		int result = Sc.deleteDataQuery(name);
//		if(result>0)
//		{
//			return "Record is deleted";
//		}
//		else 
//		{
//			return "Problem occured while deleting or no records found";
//		}
//	}
	@PutMapping("/update")
	public int updateFreeFire(@RequestParam String a,@RequestParam int b,@RequestParam String c)
	{
		return Sc.updateFootBAll(a,b,c);
	}
	
	}

