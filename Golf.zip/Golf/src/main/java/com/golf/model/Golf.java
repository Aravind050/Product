package com.golf.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Golf")
public class Golf {
	@Id
	@Column(name="team-no")
	private int teamNo;
	@Column(name="team_name")
	private String teamName;
	private int noOfPlayers;
	private int noOfSubs;
	private String captain;
	public int getTeamNo() {
		return teamNo;
	}
	public void setTeamNo(int teamNo) {
		this.teamNo = teamNo;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public int getNoOfPlayers() {
		return noOfPlayers;
	}
	public void setNoOfPlayers(int noOfPlayers) {
		this.noOfPlayers = noOfPlayers;
	}
	public int getNoOfSubs() {
		return noOfSubs;
	}
	public void setNoOfSubs(int noOfSubs) {
		this.noOfSubs = noOfSubs;
	}
	public String getCaptain() {
		return captain;
	}
	public void setCaptain(String captain) {
		this.captain = captain;
	}
	
	

}
