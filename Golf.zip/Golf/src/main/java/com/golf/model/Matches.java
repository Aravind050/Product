package com.golf.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Matches {
	@Id
	private int TeamNo;
	private String ground;
	private String Round;
	private String time;
//	@OneToMany(cascade=CascadeType.ALL)
//	@JoinColumn(name="Matches_Played")
//	private List<FootBall> MatchesPlayed;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="golf")
	private Golf golf;
	public Matches() {
		super();
	}
	public int getTeamNo() {
		return TeamNo;
	}
	public void setTeamNo(int teamNo) {
		TeamNo = teamNo;
	}
	public String getGround() {
		return ground;
	}
	public void setGround(String ground) {
		this.ground = ground;
	}
	public String getRound() {
		return Round;
	}
	public void setRound(String round) {
		Round = round;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "Matches [TeamNo=" + TeamNo + ", ground=" + ground + ", Round=" + Round + ", time=" + time + "]";
	}
//	public List<FootBall> getMatchesPlayed() {
//		return MatchesPlayed;
//	}
//	public void setMatchesPlayed(List<FootBall> matchesPlayed) {
//		MatchesPlayed = matchesPlayed;
//	}
	public Golf getGolf() {
		return golf;
	}
	public void setGolf(Golf golf) {
		this.golf = golf;
	}

}


