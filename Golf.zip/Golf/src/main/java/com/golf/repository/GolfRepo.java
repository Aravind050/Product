package com.golf.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.golf.model.Golf;

@Repository
public interface GolfRepo extends JpaRepository<Golf,Integer>{
		@Query(value="select * from Golf f where f.team_no=?1 ", nativeQuery=true)
		public List<Golf> executeQuery(int value);
		
		
		@Query(value="select * from Golf f where f.team_no=:team_no and f.team_name=:team_name",nativeQuery=true)
		public List<Golf> getDataByQuery(int team_no, String team_name);

		
		public List<Golf> findByTeamName(String field);	
		public List<Golf> findByTeamNameStartingWith(String field);
		public List<Golf> findByTeamNameEndingWith(String field);
	//
//		@Modifying
//		@Query("delete from FootBall f where f.teamName=?1")	
//		public int deleteByQuery(String teamName);

		@Modifying
		@Query("update Golf f set f.teamName=?1,f.teamNo=?2 where f.captain=?3")
		public int updateQuery( String teamName , int teamNo , String captain );

		
	}


