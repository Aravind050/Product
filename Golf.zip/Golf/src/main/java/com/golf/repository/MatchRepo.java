package com.golf.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.golf.model.Matches;

@Repository
public interface MatchRepo extends JpaRepository<Matches,Integer>{

}
