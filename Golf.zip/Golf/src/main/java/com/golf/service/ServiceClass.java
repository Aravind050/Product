package com.golf.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.golf.model.Golf;
import com.golf.model.Matches;
import com.golf.repository.GolfRepo;
import com.golf.repository.MatchRepo;

import jakarta.transaction.Transactional;

@Service
public class ServiceClass {
	@Autowired
	GolfRepo Fr;
	@Autowired
	MatchRepo Mr;
	public List<Matches> give() {
		return Mr.findAll();
	}
	public Matches create(Matches m) {
		return Mr.save(m);
	}
	public List<Golf> getbyfield(String field) {
		return Fr.findByTeamName(field);
	}
	public List<Golf> getPrefix(String field) {
		return Fr.findByTeamNameStartingWith(field);
	}
	public List<Golf> getSuffix(String field) {
		return Fr.findByTeamNameEndingWith(field);
	}
	public List<Golf> getByQuery(int a,String b) {
		return Fr.getDataByQuery(a,b);
	}
//	
	@Transactional
	public int updateFootBAll(String a, int b, String c) {
		return Fr.updateQuery(a,b,c);
	}
}
	
	
	
//	public List<Matches> getDataMatches() {
//		
//		return Mr.findAll();
//	}
//
//	public Matches saveDataMatch(Matches m) {
//		return Mr.save(m);
//	}


