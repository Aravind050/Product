package com.example.Instagram.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Instagram.Service.StudentService;
import com.example.Instagram.model.Student;

@RestController
public class ControllerClass {
@Autowired
StudentService studService;

@GetMapping(value="fetchStudents")
public List<Student> getAllStudents()
{
	List<Student> studList=studService.getAllStudents();
	return studList;
}
}
