package com.Project.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Project.Repository.ServiceClass;

import com.Project.model.Product;

@RestController
public class ControllerClass {
	@Autowired
	ServiceClass Sclass;
	@GetMapping("/hh")
	public List<Product> read()
	{
		return Sclass.get();
	}
	@PostMapping("/ha")
	public Product create(@RequestBody Product x) {
		return Sclass.add(x);
	}
	@PutMapping("/hm")
	public Product edit(@RequestBody Product y) {
		return Sclass.edit(y);
	}
	@DeleteMapping("/del/{id}")
	public String delete(@PathVariable int id) {
		return Sclass.delete(id);
	}
}
