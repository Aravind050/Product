package com.Project.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.RepositoryInterface.RepoClass;
import com.Project.model.Product;

@Service
public class ServiceClass {
	@Autowired
	RepoClass RClass;
	public List<Product> get()
	{
		return RClass.findAll();
	}
	public Product add(Product x)
	{
		return RClass.save(x);
	}
	public Product edit(Product y)
	{
		return RClass.save(y);
	}
	public String delete(int id) {
		RClass.deleteById(id);
		return id+" deleted !";
	}
}
