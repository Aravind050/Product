package com.Project.RepositoryInterface;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Project.model.Product;
@Repository
public interface RepoClass extends JpaRepository<Product, Integer> {
	
}
