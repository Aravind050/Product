package com.Project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Product {
	@Id
	private int Id;
	private String Name;
	private int Mrp;
	private String ManufactureDate;
	private String BestBefore;
	private String Weight;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getMrp() {
		return Mrp;
	}
	public void setMrp(int mrp) {
		Mrp = mrp;
	}
	public String getManufactureDate() {
		return ManufactureDate;
	}
	public void setManufactureDate(String manufactureDate) {
		ManufactureDate = manufactureDate;
	}
	public String getBestBefore() {
		return BestBefore;
	}
	public void setBestBefore(String bestBefore) {
		BestBefore = bestBefore;
	}
	public String getWeight() {
		return Weight;
	}
	public void setWeight(String weight) {
		Weight = weight;
	}
}
