package com.telegram.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.telegram.Demo.Telegram;
import com.telegram.Demo.TelegramLogin;
import com.telegram.Service.ServiceClass;

@RestController
public class ContollerClass {
@Autowired
ServiceClass Sclass;
@GetMapping("/getLoginData")
public List<TelegramLogin> getLogin()
{
	return Sclass.getLoginData();
}
@PostMapping("/login")
public String Login(@RequestBody Map<String,String> data)
{
	String userEmail = data.get("email");
	String userPassword = data.get("password");
	return Sclass.Login(userEmail,userPassword);
}
@PostMapping("/addUser")
public TelegramLogin addUser(@RequestBody TelegramLogin data)
{
	return Sclass.addUser(data);
}
@GetMapping("/getData")
public List<Telegram> getData()
{
	return Sclass.getData();
}
@PostMapping("/putData")
public Telegram putData(@RequestBody Telegram data)
{
	return Sclass.putData(data);
}
@GetMapping("/sortDataAsc/{field}")
public List<Telegram> sortDataByAsc(@PathVariable("field") String data)
{
	return Sclass.sortDataByAsc(data);
}
@GetMapping("/sortDataDesc/{field}")
public List<Telegram> sortDataByDesc(@PathVariable("field") String data)
{
	return Sclass.sortDataByDesc(data);
}
@GetMapping("/pageData/{offset}/{noofrecords}")
public Page<Telegram> pageData(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords)
{
	return Sclass.pageData(pageNo,noOfRecords);
}
@GetMapping("/pageListData/{offset}/{noofrecords}")
public List<Telegram> pageListData(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords)
{
	return Sclass.pageListData(pageNo,noOfRecords);
}
@GetMapping("/pageListDataAsc/{offset}/{noofrecords}/{field}")
public List<Telegram> pageListDataAsc(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords,@PathVariable("field") String data)
{
	return Sclass.pageListDataAsc(pageNo,noOfRecords,data);
}
@GetMapping("/pageListDataDesc/{offset}/{noofrecords}/{field}")
public List<Telegram> pageListDataDesc(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords,@PathVariable("field") String data)
{
	return Sclass.pageListDataDesc(pageNo,noOfRecords,data);
}
}
