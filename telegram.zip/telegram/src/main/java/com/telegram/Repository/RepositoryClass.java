package com.telegram.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telegram.Demo.Telegram;

@Repository
public interface RepositoryClass extends JpaRepository <Telegram,String>{

}
