package com.telegram.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.telegram.Demo.Telegram;
import com.telegram.Demo.TelegramLogin;
import com.telegram.Repository.RepositoryClass;
import com.telegram.Repository.RepositoryLogin;

@Service
public class ServiceClass {
@Autowired
RepositoryClass Repo;
@Autowired
RepositoryLogin Login;
public String Login(String email, String password) {
	try {
	TelegramLogin userEmail = Login.findById(email).get();
	if(userEmail == null)
	{
		return "Account isn't found or email incorrect";
	}
	else 
	{
		if((userEmail.getPassword()).equals(password))
		{
			return "Login Successfull";
		}
		else
		{
			return "Login Unsuccessfull! Check email and password";
		}
	}
	}
	catch(Exception e)
	{
		return "Login Unsuccessfull! Check email and password";
	}
}

public List<TelegramLogin> getLoginData() {
	return Login.findAll();
}
public TelegramLogin addUser(TelegramLogin data) {
	return Login.save(data);
}
public List<Telegram> getData() {
	return Repo.findAll();
}
public Telegram putData(Telegram data) {
	return Repo.save(data);
}
public List<Telegram> sortDataByAsc(String field) {
	return Repo.findAll(Sort.by(field));
}
public List<Telegram> sortDataByDesc(String field) {
	return Repo.findAll(Sort.by(Direction.DESC,field));
}
public Page<Telegram> pageData(int pageNo, int noOfRecords) {
	Pageable data=PageRequest.of(pageNo, noOfRecords);
	Page<Telegram> pData=Repo.findAll(data);
	return pData;
}
public List<Telegram> pageListData(int pageNo, int noOfRecords) {
	Pageable data=PageRequest.of(pageNo, noOfRecords);
	Page<Telegram> pData=Repo.findAll(data);
	return pData.getContent();
}
public List<Telegram> pageListDataAsc(int pageNo, int noOfRecords,String field) {
	Pageable data=PageRequest.of(pageNo, noOfRecords).withSort(Sort.by(field));
	Page<Telegram> pData=Repo.findAll(data);
	return pData.getContent();
}
public List<Telegram> pageListDataDesc(int pageNo, int noOfRecords,String field) {
	Pageable data=PageRequest.of(pageNo, noOfRecords).withSort(Sort.by(Direction.DESC,field));
	Page<Telegram> pData=Repo.findAll(data);
	return pData.getContent();
}

}

